<?php
$MESS['MANDARIN_MODULE_NAME_HOSTED'] = "Mandarin payment system";
$MESS['MANDARIN_MODULE_DESC_HOSTED'] = "Mandarin payment module for Bitrix CMS: \"Small business\".";
