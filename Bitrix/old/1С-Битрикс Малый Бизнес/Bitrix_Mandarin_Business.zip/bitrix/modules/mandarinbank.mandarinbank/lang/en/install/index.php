<?php
$MESS["MANDARIN_MODULE_NAME"] = "Mandarin payment system";
$MESS["MANDARIN_MODULE_DESC"] = "Mandarin payment module for Bitrix CMS: \"Small business\".";
?>