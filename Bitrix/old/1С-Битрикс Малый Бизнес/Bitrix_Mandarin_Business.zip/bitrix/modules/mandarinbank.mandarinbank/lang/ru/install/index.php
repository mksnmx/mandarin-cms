<?php
$MESS["MANDARIN_MODULE_NAME"] = "Платёжная система Мандарин";
$MESS["MANDARIN_MODULE_DESC"] = "Платёжный модуль системы Мандарин для Bitrix CMS: \"Small business\".";
?>