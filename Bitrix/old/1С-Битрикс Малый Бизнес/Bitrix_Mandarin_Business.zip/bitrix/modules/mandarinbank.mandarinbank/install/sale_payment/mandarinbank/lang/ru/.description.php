<?php
global $MESS;

$MESS["MANDARIN_MERCH_ID"] = "ID кошелька";
$MESS["MANDARIN_SEC_KEY"] = "Секретный ключ";


$MESS["order_id"] = "Номер заказа";
$MESS["MANDARIN_PAY_AMOUNT"] = "Сумма к оплате";

$MESS["PAYSYS_MOD_TITLE"] = "Платёжная система";
// #c7f9a5
$MESS["MANDARIN_DESCR"] = "<div style='background: #F09000; border-radius: 5px; border: 1px solid; border-color: #409605; color: #000; display: inline-block; margin: 16px 0; padding: 15px 30px 15px 18px;'>
Платежный сервис <a href='https://mandarinbank.com/' target='_blank'>mandarinbank.com</a>

<p>URL взаимодействия<br/>
<input type='text' readonly value='#response_url#' size='90' /></p>

<p>URL успешной оплаты<br/>
<input type='text' readonly value='#suc_url#' size='90' /></p>

<p>URL неудачной оплаты<br/>
<input type='text' readonly value='#fail_url#' size='90' /></p>";

$MESS["email_client"] = "Email покупателя";