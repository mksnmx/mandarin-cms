<?php 
/**
* @version      5.0.0 15.09.2018
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die();?>
<div class="jshop_log_info">
<?php print $this->tmp_html_start?>
<pre>
<?php print $this->data?>
</pre>
<?php print $this->tmp_html_end?>
</div>