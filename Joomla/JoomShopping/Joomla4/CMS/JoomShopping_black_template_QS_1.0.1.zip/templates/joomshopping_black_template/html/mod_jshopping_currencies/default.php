<div class="currency">
	<?php print $currencies_display_list; ?>
</div>