<?php

include_once __DIR__ . '/InstallHelper.php';

$name = "JoomShopping 'Joomshopping Black Template'";
$element = "joomshopping_black_template";
$version = "1.0.1";
$cache = addslashes('{"creationDate":"01.05.2018","author":"MAXXmarketing GmbH","authorEmail":"marketing@maxx-marketing.net","authorUrl":"http://www.webdesigner-profi.de","version":"'.$version.'"}');

$addon = JTable::getInstance('addon', 'jshop');
$addon->loadAlias('addon_'.$element);
$addon->set('name', $name);
$addon->set('version', $version);
$addon->set('uninstall','/components/com_jshopping/addons/addon_'.$element.'/uninstall.php');
$addon->store();	

$addon = JTable::getInstance('addon', 'jshop');

if (!InstallHelper::isEnable('BASKET', 'mod_jshopping_cart_ext')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'BASKET', 
			'type' => 'module',
			'element' => 'mod_jshopping_cart_ext', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'basket'
		)
	);

	InstallHelper::installJoomlaModule(
		array(
			'title' => 'BASKET', 
			'module' => 'mod_jshopping_cart_ext',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"show_count":"1","show_tax":"1","show_basic_price":"1","show_total_tax":"1","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'basket'
		),
		0
	);
}


if (!InstallHelper::isEnable('BESTSELLER PRODUCTS', 'mod_jshopping_bestseller_products')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'BESTSELLER PRODUCTS', 
			'type' => 'module',
			'element' => 'mod_jshopping_bestseller_products', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'bestseller-products'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'BESTSELLER PRODUCTS', 
			'module' => 'mod_jshopping_bestseller_products',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"count_products":"6","catids":[""],"enable_addon":"1","show_image":"1","show_image_label":"0","allow_review":"0","short_description":"1","manufacturer_name":"0","product_quantity":"0","product_old_price":"0","product_price_default":"0","display_price":"1","show_tax_product":"0","show_plus_shipping_in_product":"0","basic_price_info":"0","product_weight":"0","delivery_time":"0","extra_field":"0","vendor":"0","product_list_qty_stock":"0","show_button":"1","show_button_buy":"1","show_button_detal":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'bestseller-products'
		),
		1
	);
}

if (!InstallHelper::isEnable('Jshopping Categories', 'mod_jshopping_categories')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'Jshopping Categories', 
			'type' => 'module',
			'element' => 'mod_jshopping_categories', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'categories'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Jshopping Categories',
			'module' => 'mod_jshopping_categories',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"show_image":"0","sort":"id","ordering":"asc","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'categories'
		),
		0
	);
}

if (!InstallHelper::isEnable('CATEGORIES', 'mod_jshopping_categories')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'CATEGORIES', 
			'type' => 'module',
			'element' => 'mod_jshopping_categories', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'categories-two'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'CATEGORIES',
			'module' => 'mod_jshopping_categories',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"show_image":"0","sort":"id","ordering":"asc","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'categories-two'
		),
		0
	);
}


if (!InstallHelper::isEnable('CURRENCY', 'mod_jshopping_currencies')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'CURRENCY', 
			'type' => 'module',
			'element' => 'mod_jshopping_currencies', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'currency'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'CURRENCY',
			'module' => 'mod_jshopping_currencies',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'currency'
		),
		0
	);
}

if (!InstallHelper::isEnable('home-image', 'mod_custom')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'home-image', 
			'type' => 'module',
			'element' => 'mod_custom', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'home-image'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'home-image',
			'module' => 'mod_custom',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'content' => '<p><img src="images/joomshoppingpdemo.png" width="100%" /></p>',
			'params' => '{"prepare_content":0,"backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":1,"cache_time":900,"cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'showtitle' => 0,
			'position' => 'home-image'
		),
		1
	);
}

if (!InstallHelper::isEnable('SALES PRODUCTS', 'mod_jshopping_label_products')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'SALES PRODUCTS', 
			'type' => 'module',
			'element' => 'mod_jshopping_label_products', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'label-products'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'SALES PRODUCTS',
			'module' => 'mod_jshopping_label_products',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"count_products":"6","label_id":"","enable_addon":"1","show_image":"1","show_image_label":"0","allow_review":"0","short_description":"0","manufacturer_name":"0","product_quantity":"0","product_old_price":"1","product_price_default":"1","display_price":"1","show_tax_product":"0","show_plus_shipping_in_product":"0","basic_price_info":"0","product_weight":"0","delivery_time":"0","extra_field":"0","vendor":"0","product_list_qty_stock":"0","show_button":"1","show_button_buy":"1","show_button_detal":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'label-products'
		),
		1
	);
}

if (!InstallHelper::isEnable('Language change', 'mod_languages')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'Language change', 
			'type' => 'module',
			'element' => 'mod_languages', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 0, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'language-change'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Language change',
			'module' => 'mod_languages',
			'ordering' => 1,
			'published' => 0,
			'access' => 1,
			'language' => '*',
			'params' => '{"header_text":"","footer_text":"","dropdown":0,"dropdownimage":1,"lineheight":0,"image":1,"show_active":1,"full_name":1,"inline":1,"layout":"_:default","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'language-change'
		),
		0
	);
}

if (!InstallHelper::isEnable('LATEST PRODUCTS', 'mod_jshopping_latest_products')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'LATEST PRODUCTS', 
			'type' => 'module',
			'element' => 'mod_jshopping_latest_products', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'latest-products'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'LATEST PRODUCTS',
			'module' => 'mod_jshopping_latest_products',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"count_products":"3","catids":[""],"order_by":"product_id","enable_addon":"1","show_image":"1","show_image_label":"0","allow_review":"0","short_description":"0","manufacturer_name":"0","product_quantity":"0","product_old_price":"0","product_price_default":"0","display_price":"1","show_tax_product":"0","show_plus_shipping_in_product":"0","basic_price_info":"0","product_weight":"0","delivery_time":"0","extra_field":"0","vendor":"0","product_list_qty_stock":"0","show_button":"1","show_button_buy":"1","show_button_detal":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'latest-products'
		),
		1
	);
}

if (!InstallHelper::isEnable('Login', 'mod_menu')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'Login', 
			'type' => 'module',
			'element' => 'mod_menu', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'login-menu'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Login',
			'module' => 'mod_menu',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"menutype":"login-en","base":"","startLevel":1,"endLevel":0,"showAllChildren":1,"tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":1,"cache_time":900,"cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'login-menu'
		),
		0
	);
}

if (!InstallHelper::isEnable('Main Menu', 'mod_menu')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'Main Menu', 
			'type' => 'module',
			'element' => 'mod_menu', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'main-menu'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Main Menu',
			'module' => 'mod_menu',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"menutype":"main-menu-en","base":"","startLevel":1,"endLevel":0,"showAllChildren":1,"tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":1,"cache_time":900,"cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'main-menu'
		),
		0
	);
}

if (!InstallHelper::isEnable('MANUFACTURERS', 'mod_jshopping_manufacturers')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'MANUFACTURERS', 
			'type' => 'module',
			'element' => 'mod_jshopping_manufacturers', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'manufactures'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'MANUFACTURERS',
			'module' => 'mod_jshopping_manufacturers',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"show_image":"0","sort":"id","ordering":"asc","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'manufactures'
		),
		0
	);
}

if (!InstallHelper::isEnable('SEARCH', 'mod_jshopping_search')) {
	
	$addon->installJoomlaExtension(
		array(
			'name' => 'SEARCH', 
			'type' => 'module',
			'element' => 'mod_jshopping_search', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'module-search'
		)
	);

	InstallHelper::installJoomlaModule(
		array(
			'title' => 'SEARCH',
			'module' => 'mod_jshopping_search',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"advanced_search":"1","category_id":"","moduleclass_sfx":"","search_type":"any","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'module-search'
		),
		0
	);
}

if (!InstallHelper::isEnable('Breadcrumbs', 'mod_breadcrumbs')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'Breadcrumbs', 
			'type' => 'module',
			'element' => 'mod_breadcrumbs', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'position-2'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Breadcrumbs',
			'module' => 'mod_breadcrumbs',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"showHere":1,"showHome":1,"homeText":"","showLast":1,"separator":"","layout":"_:default","moduleclass_sfx":"","cache":0,"cache_time":0,"cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'position-2'
		),
		0
	);
}

if (!InstallHelper::isEnable('Login Form', 'mod_login')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'Login Form', 
			'type' => 'module',
			'element' => 'mod_login', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'position-7'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Login Form',
			'module' => 'mod_login',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"pretext":"","posttext":"","login":"","logout":"","greeting":1,"name":0,"profilelink":0,"usesecure":0,"usetext":0,"layout":"_:default","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'position-7'
		),
		0
	);
}

if (!InstallHelper::isEnable('TOP RATING PRODUCTS', 'mod_jshopping_top_rating')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'TOP RATING PRODUCTS', 
			'type' => 'module',
			'element' => 'mod_jshopping_top_rating', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'rating-products'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'TOP RATING PRODUCTS',
			'module' => 'mod_jshopping_top_rating',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"count_products":"2","enable_addon":"1","show_image":"1","show_image_label":"0","allow_review":"0","short_description":"0","manufacturer_name":"0","product_quantity":"0","product_old_price":"0","product_price_default":"0","display_price":"1","show_tax_product":"0","show_plus_shipping_in_product":"0","basic_price_info":"0","product_weight":"0","delivery_time":"0","extra_field":"0","vendor":"0","product_list_qty_stock":"0","show_button":"0","show_button_buy":"0","show_button_detal":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'rating-products'
		),
		0
	);
}

if (!InstallHelper::isEnable('RECENT COMMENTS', 'mod_recent_comments')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'RECENT COMMENTS', 
			'type' => 'module',
			'element' => 'mod_recent_comments', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'recent-comments'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'RECENT COMMENTS',
			'module' => 'mod_recent_comments',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"count":"2","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'recent-comments'
		),
		0
	);
}

if (!InstallHelper::isEnable('Shop', 'mod_custom')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'RECENT COMMENTS', 
			'type' => 'module',
			'element' => 'mod_custom', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'shop'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'Shop',
			'module' => 'mod_custom',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"prepare_content":0,"backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":1,"cache_time":900,"cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'shop'
		),
		0
	);
}

if (!InstallHelper::isEnable('TOP HITS PRODUCTS', 'mod_jshopping_tophits_products')) {

	$addon->installJoomlaExtension(
		array(
			'name' => 'TOP HITS PRODUCTS', 
			'type' => 'module',
			'element' => 'mod_jshopping_tophits_products', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'top-hits-products'
		)
	);
	
	InstallHelper::installJoomlaModule(
		array(
			'title' => 'TOP HITS PRODUCTS',
			'module' => 'mod_jshopping_tophits_products',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"count_products":"2","enable_addon":"1","catids":[""],"show_image":"1","show_image_label":"0","allow_review":"0","short_description":"0","manufacturer_name":"0","product_quantity":"0","product_old_price":"0","product_price_default":"0","display_price":"1","show_tax_product":"0","show_plus_shipping_in_product":"0","basic_price_info":"0","product_weight":"0","delivery_time":"0","extra_field":"0","vendor":"0","product_list_qty_stock":"0","show_button":"1","show_button_buy":"0","show_button_detal":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'top-hits-products'
		),
		0
	);
}

if (!InstallHelper::isEnable('WISHLIST', 'mod_jshopping_wishlist')) {
	
	$addon->installJoomlaExtension(
		array(
			'name' => 'WISHLIST', 
			'type' => 'module',
			'element' => 'mod_jshopping_wishlist', 
			'folder' => '', 
			'client_id' => 0, 
			'enabled' => 1, 
			'access' => 1, 
			'protected' => 0, 
			'position' => 'wishlist'
		)
	);

	InstallHelper::installJoomlaModule(
		array(
			'title' => 'WISHLIST',
			'module' => 'mod_jshopping_wishlist',
			'ordering' => 1,
			'published' => 1,
			'access' => 1,
			'language' => '*',
			'params' => '{"moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}',
			'position' => 'wishlist'
		),
		0
	);
}
$addon->installJoomlaExtension(
	array(
		'name' => 'Joomshopping black template', 
		'type' => 'template',
		'element' => 'joomshopping_black_template', 
		'folder' => '', 
		'client_id' => 0, 
		'enabled' => 1, 
		'access' => 1, 
		'protected' => 0, 
	)
);

InstallHelper::installTemplateData('joomshopping_black_template', 'Joomshopping black template');
InstallHelper::setDefaultTemplateForJoomshopping();