<?php defined('_JEXEC') or die();?>
<div class="no_products_filter">
    <?php print _JSHOP_NO_PRODUCTS_AFTER_FILTER?>
</div>