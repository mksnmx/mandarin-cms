<?php defined('_JEXEC') or die(); ?>
<table class="jshop_pagination">
<tr>
    <td><div class="pagination"><?php print $this->pagination?></div></td>
</tr>
</table>