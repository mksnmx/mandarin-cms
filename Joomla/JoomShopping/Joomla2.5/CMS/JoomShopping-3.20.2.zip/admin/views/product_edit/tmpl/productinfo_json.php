<?php 
	defined('_JEXEC') or die();
	print json_encode($this->res);
?>