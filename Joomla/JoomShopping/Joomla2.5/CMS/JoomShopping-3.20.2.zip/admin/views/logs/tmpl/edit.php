<?php defined('_JEXEC') or die();?>
<div class="jshop_log_info">
<?php print $this->tmp_html_start?>
<pre>
<?php print $this->data?>
</pre>
<?php print $this->tmp_html_end?>
</div>