<?php defined('_JEXEC') or die(); ?>
<?php print $this->tmp_html_start?>
<table width = "100%">
<tr>
    <td>
        <div id = "cpanel">
        <?php displayOptionPanelIco(); ?>
        </div>
    </td>
</tr>
</table>
<?php print $this->tmp_html_end?>