<?php defined('_JEXEC') or die(); ?>
<script type="text/javascript">
function check_pm_mandarin(){
    jQuery('#payment_form').submit();
}
</script>