<?php
return array(
    'php.curl'               => array(
        'strict' => false,
        'value'  => 1,
    ),
    'phpini.allow_url_fopen' => array(
        'strict' => false,
        'value'  => 1,
    ),
);
