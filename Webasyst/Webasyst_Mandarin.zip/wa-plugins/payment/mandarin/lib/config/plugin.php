<?php
return array(
    'name'        => 'MandarinBank',
    'description' => 'Нажав кнопку Оплатить счет, Вы перейдете в шлюз оплаты сервиса MANDARINBANK, где Вам будет предложено оплатить заказ любым удобным способом: картами Visa, MasterCard, Яндекс-Деньги, Webmoney, терминалы QIWI',
    'icon'        => 'image.php',
    'logo'        => 'image.php',
    'vendor'      => 'vuchastyi',
    'version'     => '1.0.2',
    'locale'      => array('ru_RU',),
    'type'        => waPayment::TYPE_ONLINE,
);
