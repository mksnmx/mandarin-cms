<?php
// Text
$_['text_title'] 			= 'MandarinBank';
