<?php
// Text
$_['text_title'] = 'Оплата Мандарин банк';
?>