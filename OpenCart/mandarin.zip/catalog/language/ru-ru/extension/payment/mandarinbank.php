<?php
// Text
$_['text_title'] 			= 'MandarinBank';
$_['errors_payment'] 			= 'Ошибекп при оплате';
$_['success_payment'] 			= 'Успешно оплаченный';
