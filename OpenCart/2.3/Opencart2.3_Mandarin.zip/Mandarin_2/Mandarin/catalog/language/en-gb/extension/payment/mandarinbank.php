<?php
// Text
$_['text_title'] = 'MandarinBank';
$_['errors_payment'] 			= 'Payment error';
$_['success_payment'] 			= 'Successful payment';