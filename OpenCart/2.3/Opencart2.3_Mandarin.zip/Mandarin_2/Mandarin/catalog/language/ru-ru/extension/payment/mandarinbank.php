<?php
// Text
$_['text_title'] 			= 'MandarinBank';
$_['errors_payment'] 			= 'Ошибка при оплате';
$_['success_payment'] 			= 'Успешная оплата';
