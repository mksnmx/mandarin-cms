<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Törlés';
$_lang['error_log'] = 'Hibanapló';
$_lang['error_log_desc'] = 'MODX Revolution hibanapló:';
$_lang['error_log_download'] = 'Hibanapló letöltése ([[+size]])';
$_lang['error_log_too_large'] = 'A(z) <em>[[+name]]</em> hibanaplója túl nagy méretű a megtekintéshez. Az alábbi gombbal azonban letöltheti.';
$_lang['system_events'] = 'Rendszeresemények';
$_lang['priority'] = 'Prioritás';