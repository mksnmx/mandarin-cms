<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Hiba!';
$_lang['rest.err_class_remove'] = 'Hiba történt a következő eltávolítása közben: [[+ class_key]]';
$_lang['rest.err_class_save'] = 'Hiba történt a következő mentése közben: [[+ class_key]]';
$_lang['rest.err_field_ns'] = '[[+ mező]] nincs megadva!';
$_lang['rest.err_field_required'] = 'This field is required.';
$_lang['rest.err_fields_required'] = 'A következő mezők kitöltése kötelező: [[+ mezők]]';
$_lang['rest.err_obj_nf'] = '[[+ class_key]] nem található!';
