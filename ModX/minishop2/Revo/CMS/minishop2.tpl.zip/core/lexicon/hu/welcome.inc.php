<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'MODX Hírek';
$_lang['security_notices'] = 'Biztonsági figyelmeztetések';
$_lang['welcome_messages'] = 'A postafiókja <strong>%d</strong> üzenetet tartalmaz, melyből <strong>%s</strong> olvasatlan.';
$_lang['welcome_title'] = 'Üdvözli Önt a MODX CMS!';
$_lang['yourinfo_message'] = 'Ez a szakasz bizonyos adatait mutatja meg:';
$_lang['yourinfo_previous_login'] = 'Utolsó belépés:';
$_lang['yourinfo_title'] = 'Saját adatai';
$_lang['yourinfo_total_logins'] = 'Bejelentkezések száma:';
$_lang['yourinfo_username'] = 'Bejelentkezve mint:';