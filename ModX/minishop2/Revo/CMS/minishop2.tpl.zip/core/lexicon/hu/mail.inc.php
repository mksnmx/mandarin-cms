<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Meg kell adnia egy e-mail címet.';
$_lang['mail_err_derive_getmailer'] = 'Attempt to call abstract function _getMailer() in modMail class. You must implement this function in a derivative of modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] érvénytelen PHPMailer attribútum, ezért figyelmen kívül hagyásra kerül.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer does not support unsetting specific addresses. Use reset() to clear all recipients and add back the ones you want to send to.';