<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Kesalahan!';
$_lang['rest.err_class_remove'] = 'Terjadi kesalahan saat mencoba untuk menghapus [[+class_key]]';
$_lang['rest.err_class_save'] = 'Terjadi kesalahan saat mencoba untuk menyimpan [[+class_key]]';
$_lang['rest.err_field_ns'] = '[[+field]] tidak ditentukan!';
$_lang['rest.err_field_required'] = 'Bidang ini diperlukan.';
$_lang['rest.err_fields_required'] = 'Bidang berikut harus diisi: [[+fields]]';
$_lang['rest.err_obj_nf'] = '[[+class_key]] tidak ditemukan!';
