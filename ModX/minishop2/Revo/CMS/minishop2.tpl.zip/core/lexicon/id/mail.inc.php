<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Anda harus memberikan alamat email untuk tujuan pengiriman.';
$_lang['mail_err_derive_getmailer'] = 'Mencoba untuk memanggil fungsi abstrak _getMailer() di kelas modMail. Anda harus menerapkan fungsi ini di turunan dari modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] bukanlah atribut PHPMailer yang berlaku dan sedang diabaikan dalam implementasi.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer tidak mendukung pembatalan setelan pada alamat tertentu. Gunakan reset() untuk menghapus semua penerima dan tambahkan kembali orang-orang yang ingin Anda kirim.';