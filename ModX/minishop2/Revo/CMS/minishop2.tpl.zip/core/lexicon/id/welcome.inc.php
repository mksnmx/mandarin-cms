<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'MODX Berita';
$_lang['security_notices'] = 'Pemberitahuan keamanan';
$_lang['welcome_messages'] = 'Kotak masuk Anda berisi pesan <strong>%d</strong>, (pesan) yang <strong>%s</strong> belum dibaca.';
$_lang['welcome_title'] = 'Selamat datang Anda MODX Content Manager';
$_lang['yourinfo_message'] = 'Bagian ini menunjukkan beberapa informasi mengenai Anda:';
$_lang['yourinfo_previous_login'] = 'Masuk terakhir:';
$_lang['yourinfo_title'] = 'Info Anda';
$_lang['yourinfo_total_logins'] = 'Total jumlah login:';
$_lang['yourinfo_username'] = 'Anda login sebagai:';