<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Jelas';
$_lang['error_log'] = 'Log kesalahan';
$_lang['error_log_desc'] = 'Berikut adalah log kesalahan untuk MODX Revolusi:';
$_lang['error_log_download'] = 'Men-download Log kesalahan ([[+size]])';
$_lang['error_log_too_large'] = 'Log kesalahan di <em>[[+name]]</em> terlalu besar untuk dilihat. Anda dapat mendownload melalui tombol di bawah ini.';
$_lang['system_events'] = 'Sistem kegiatan';
$_lang['priority'] = 'Prioritas';