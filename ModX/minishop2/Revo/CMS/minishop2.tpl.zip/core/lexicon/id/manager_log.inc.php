<?php
/**
 * Manager Log English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['action'] = 'Aksi';
$_lang['date_end'] = 'Tanggal berakhir';
$_lang['date_start'] = 'Tanggal mulai';
$_lang['filter_clear'] = 'Hapus Filter';
$_lang['manager_log'] = 'Manajer Log';
$_lang['mgrlog_clear'] = 'Mengosongkan Manager Log';
$_lang['mgrlog_clear_confirm'] = 'Apakah Anda yakin Anda ingin benar-benar mengosongkan log Manajer? Ini tidak bisa dibatalkan.';
$_lang['mgrlog_query_msg'] = 'Silakan membuat seleksi untuk melihat log. Anda dapat memilih entri log dengan tanggal, tetapi menyadari bahwa tanggal yang Anda masukkan tidak inclusive - pilih setiap entri log untuk 01-01-2004, mengatur \'tanggal mulai\' untuk 01-01-2004 dan \'tanggal akhir\' 02-01-2004.';
$_lang['mgrlog_query'] = 'Pencatatan Query';
$_lang['mgrlog_view'] = 'Lihat manajer log';
$_lang['object'] = 'Objek';
$_lang['occurred'] = 'Terjadi';
$_lang['user'] = 'Pengguna';