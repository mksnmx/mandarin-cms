<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Erro!';
$_lang['rest.err_class_remove'] = 'Ocorreu um erro ao tentar remover o [[+class_key]]';
$_lang['rest.err_class_save'] = 'Ocorreu um erro ao tentar salvar o [[+class_key]]';
$_lang['rest.err_field_ns'] = '[[+campo]] não especificado';
$_lang['rest.err_field_required'] = 'Esta campo é obrigatório.';
$_lang['rest.err_fields_required'] = 'Os seguintes campos são obrigatórios: [[+fields]]';
$_lang['rest.err_obj_nf'] = '[[+class_key]] não encontrado!';
