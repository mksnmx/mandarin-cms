<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Você deve fornecer um endereço de e-mail para enviar.';
$_lang['mail_err_derive_getmailer'] = 'Tentativa de chamar a função abstrata _getMailer() na classe modMail. Você deve implementar essa função em um derivado do modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] não é um atributo PHPMailer válido e está sendo ignorada pela implementação.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer não oferece suporte a desactivação endereços específicos. Use reset() para limpar todos os destinatários e adicionar novamente o que deseja enviar.';