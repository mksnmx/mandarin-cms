<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Для отправки письма вы должны предоставить электронный почту получателя.';
$_lang['mail_err_derive_getmailer'] = 'Произошла попытка вызова абстрактного метода _getMailer() в классе modMail. Вы должны переопределить этот метод в наследуемом классе.';
$_lang['mail_err_attr_nv'] = '[[+attr]] — это неправильный атрибут класса PHPMailer и будет игнорирован системой.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer не поддерживает отмену отправки по некоторым адресам. Используйте метод reset() для очистки всех получателей и после этого добавьте нужных получателей снова.';