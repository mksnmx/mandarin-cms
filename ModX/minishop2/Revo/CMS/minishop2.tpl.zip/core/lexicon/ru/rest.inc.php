<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'Ошибка!';
$_lang['rest.err_class_remove'] = 'Произошла ошибка при попытке удалить [[+class_key]]';
$_lang['rest.err_class_save'] = 'Произошла ошибка при попытке сохранить [[+class_key]]';
$_lang['rest.err_field_ns'] = 'Поле [[+field]] не задано!';
$_lang['rest.err_field_required'] = 'Это поле обязательно для заполнения.';
$_lang['rest.err_fields_required'] = 'Следующие поля являются обязательными: [[+fields]]';
$_lang['rest.err_obj_nf'] = 'Объект класса [[+class_key]] не найден!';
