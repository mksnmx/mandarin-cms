<?php
/**
 * English Preload Lexicon Topic for Revolution setup
 *
 * @package setup
 * @subpackage lexicon
 */
$_lang['preload_err_cache'] = 'Уверете се, че вашаат [[+path]]кеш директория съществува и е възможна за записване от PHP процеса.';
$_lang['preload_err_core_path'] = 'Уверете се, че сте задали валидна MODX_CORE_PATH във вашия setup/includes/config.core.php файл; това трябва да сочи към работещо MODX ядро.';
$_lang['preload_err_pdo'] = 'MODX изисква PDO разширение, когато се използва местен PDO  и не се появява за зареждане.';