<?php
/**
 * English Preload Lexicon Topic for Revolution setup
 *
 * @package setup
 * @subpackage lexicon
 */
$_lang['preload_err_cache'] = 'تأكد من أن دليل الذاكرة المخبئية لـ [[+path]] موجود وقابل للكتابة عن طريق عملية PHP.';
$_lang['preload_err_core_path'] = 'تأكد من أنك حددت MODX_CORE_PATH صالح في الملف setup/includes/config.core.php؛ يجب أن يشير إلى نواة مودكس التي تعمل.';
$_lang['preload_err_pdo'] = 'مودكس يتطلب لاحقة pdo_mysql عند استخدام PDO الأصلي، ولا يبدو أنه محمل.';