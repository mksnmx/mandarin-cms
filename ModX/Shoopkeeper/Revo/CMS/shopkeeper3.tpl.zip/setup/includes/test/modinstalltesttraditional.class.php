<?php
/**
 * Handles all traditional build-specific checks
 *
 * @package setup
 * @subpackage tests
 */
class modInstallTestTraditional extends modInstallTest {}