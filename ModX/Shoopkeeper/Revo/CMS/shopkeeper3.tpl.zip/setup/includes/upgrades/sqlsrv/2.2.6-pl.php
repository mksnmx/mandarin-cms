<?php
/* disable allow_tags_in_post System Setting */
include dirname(dirname(__FILE__)).'/common/2.2-disable-allowtagsinpost.php';
