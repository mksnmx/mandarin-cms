<?php
$classes = array(
    'modAccessNamespace',
);

if (!empty($classes)) {
    $this->createTable($classes);
}