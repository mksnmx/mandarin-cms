<?php
/*1
 * Specific upgrades for Revolution 2.5.5-pl
 *
 * @var modX $modx
 * @package setup
 * @subpackage upgrades
 */

/* run upgrades common to all db platforms */
include dirname(dirname(__FILE__)) . '/common/2.5.5-ssl-provider.php';
