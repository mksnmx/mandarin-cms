<?php
/*1
 * Specific upgrades for Revolution 2.4.1-pl
 *
 * @var modX $modx
 * @package setup
 * @subpackage upgrades
 */

/* run upgrades common to all db platforms */
include dirname(dirname(__FILE__)) . '/common/2.4.1-namespace-access.php';
