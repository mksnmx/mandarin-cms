<?php
/**
 * Welcome English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'Noticias de MODX';
$_lang['security_notices'] = 'Notas de Seguridad';
$_lang['welcome_messages'] = 'Tu bandeja de entrada contiene <strong>%d</strong> mensaje(s), <strong>%s</strong> no leídos.';
$_lang['welcome_title'] = 'Bienvenido al Administrador de Contenido de MODX';
$_lang['yourinfo_message'] = 'Esta sección muestra información acerca de tí:';
$_lang['yourinfo_previous_login'] = 'Tu último inicio de sesión:';
$_lang['yourinfo_title'] = 'Tu información';
$_lang['yourinfo_total_logins'] = 'Número total de veces que has iniciado sesión:';
$_lang['yourinfo_username'] = 'Has iniciado sesión sesión como:';