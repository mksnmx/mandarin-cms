<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Vymazat';
$_lang['error_log'] = 'Chybové zprávy';
$_lang['error_log_desc'] = 'Chybové zprávy z MODX Revolution:';
$_lang['error_log_download'] = 'Stáhnout chybové zprávy ([[+size]])';
$_lang['error_log_too_large'] = 'Výpis chybových zpráv pro <em>[[+name]]</em> je příliš velký a nelze jej zobrazit. Můžete si jej stáhnout tlačítkem níže.';
$_lang['system_events'] = 'Systémové události';
$_lang['priority'] = 'Priorita';