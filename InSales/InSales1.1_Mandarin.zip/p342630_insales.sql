-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Хост: p342630.mysql.ihc.ru
-- Время создания: Май 05 2016 г., 00:44
-- Версия сервера: 5.5.45-37.4-log
-- Версия PHP: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `p342630_insales`
--

-- --------------------------------------------------------

--
-- Структура таблицы `merchants`
--

CREATE TABLE `merchants` (
  `id` int(11) NOT NULL,
  `merchant_id` int(11) NOT NULL,
  `merchantName` varchar(100) NOT NULL,
  `passw1` varchar(50) NOT NULL COMMENT 'для InSales',
  `passw2` varchar(50) NOT NULL COMMENT 'для MandarinPay',
  `url_insales` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `merchants`
--

INSERT INTO `merchants` (`id`, `merchant_id`, `merchantName`, `passw1`, `passw2`, `url_insales`) VALUES
(1, 75, 'Магазин электроники', 'super', '510KcfmFAi', 'http://shop-52673.myinsales.ru/payments/external/369932/success');

-- --------------------------------------------------------

--
-- Структура таблицы `transactions`
--

CREATE TABLE `transactions` (
  `order_id` int(11) NOT NULL,
  `key` char(32) NOT NULL,
  `transaction` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `transactions`
--

INSERT INTO `transactions` (`order_id`, `key`, `transaction`) VALUES
(7286704, '8d48307802f3b9cdaa4523370d5fe605', 2775953);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `merchants`
--
ALTER TABLE `merchants`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`order_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `merchants`
--
ALTER TABLE `merchants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
