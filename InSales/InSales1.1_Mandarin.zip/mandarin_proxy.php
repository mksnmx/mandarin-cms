<?php

//http://www.anti-kontrafakt.ru/offshore-soft/project_12_insales/mandarin_proxy.php





/********************************************/		
		//константы для соединения с базой данных
		require_once ('db_config.php');

/********************************************/	

		
		
//====ПРИЕМ ОБРАТНОЙ ПЛАТЕЖНОЙ ФОРМЫ ОТ ПЛАТЕЖНОГО ТЕРМИНАЛА - 
//ловим по наличию поля payment_system                             ============
if( isset($_POST['payment_system']) )
{//========ВТОРАЯ ПЛАТЕЖНАЯ ФОРМА ===================================================================================================================== 
	$pay_system = $_POST['payment_system'];
	if ( preg_match('/mandarinpay/i', $pay_system ) )
	{//=== проверяем, что точно от МандаринПей ===========

		//===наполняем массив параметрами, чьи имена не будут меняться========================
		$return_field = array ( 'merchantId'     => $_POST['merchantId'],
								'price'          => $_POST['price'],
								'orderId'        => $_POST['orderId'],
								'email'          => $_POST['email'],
								'status'         => $_POST['status'], 
								'transaction'    => $_POST['transaction'], 
								'payment_system' => $_POST['payment_system'] 	 );
		$return_sent_sign   =  $_POST['sign'];					 
		
		//читаем весь POST запрос
		$postData    = $_POST;
		//а теперь дозаполняем массив $field динамическими полями----
		foreach ( $postData as $key => $value ) 
		{
			if(  ($key !== 'merchantId')   && ($key !== 'price')  &&  ($key !== 'orderId') &&
				 ($key !== 'email') &&  ($key !== 'status')  &&  ($key !== 'transaction') &&
				 ($key !== 'payment_system') && ($key !== 'sign')    )
			{
					$return_field[$key] = $value;		
					// если массив - то удаляем этот элемент из $return_field[]  
					if(  is_array( $return_field[$key] ) )  unset( $return_field[$key] );
				
			}				 
		}//--------------------------------------------------------------------	
		
	
	    //===== читаем SharedSec из базы данных, по известному merchantId===========================
			$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
			$mysqli->set_charset("utf8");

			if ($mysqli->connect_error) {
				die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
			}

			$merchant_id = $return_field['merchantId'];
			$results = $mysqli->query("SELECT * FROM merchants WHERE merchant_id = $merchant_id");
			
			if( $row = $results->fetch_assoc() )
			{
				$mandarinpay_secret = 				$row['passw2'];
			}
			$results->free();
			$mysqli->close();
		//===== читаем SharedSec из базы данных, по известному merchantId===========================
	
	
	
		
		
		$return_right_sign = getHash ($mandarinpay_secret, $return_field);
		
		if( $return_sent_sign == $return_right_sign )
		{//=========если данные ЦЕЛОСТНЫЕ===================================================
	    if ( $return_field['status'] == 'success'  )
		{//=========если статус транзакции = SUCCESS========================================
	
			//==== берем из базы данных key и transaction_id по известному order_id==========
			$order = $return_field['orderId'];
			
			$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
			$mysqli->set_charset("utf8");

			//Output any connection error
			if ($mysqli->connect_error) {
				die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
			}

			//MySqli Select Query
			$results = $mysqli->query("SELECT * FROM transactions WHERE order_id = $order");
			
			if( $row = $results->fetch_assoc() )
			{
				$key_from_DB = 				$row['key'];
				$transaction_id_from_DB = 	$row['transaction'];
				$da = "\n\nДанные подняты! Вот они $key_from_DB   +  $transaction_id_from_DB";
			}
			$results->free();
			
			//берем passw1 для подписи и отправки в InSales + url_insales
			$merchant_id = $return_field['merchantId'];
			$results = $mysqli->query("SELECT * FROM merchants WHERE merchant_id = $merchant_id");
			
			if( $row = $results->fetch_assoc() )
			{
				$password = $row['passw1'];
				$url_insales =  $row['url_insales'];
			}
				
			//для отладки
			$text = "\n\nУдалось прочитат пароль для InSales - $password";	
				
				
			$results->free();
			$mysqli->close();
			//================================================================================
	
	
			//========ОТПРАВЛЯЕМ POST-ЗАПРОС к INSALES========================================
   
			//Подпись. Формируется как MD5 от "shop_id;amount;transaction_id;key;paid;password".
			$amount = $return_field['price'];
			$signature = md5(	$merchant_id.";".
								$amount.";".
								$transaction_id_from_DB.";".
								$key_from_DB.";".
								"1".";".
								$password  );
								

				$prepared_array = array(
										'paid' => 			"1",
										'amount' => 		$amount,
										'key' => 			$key_from_DB,
										'transaction_id' => $transaction_id_from_DB,
										'signature' => 		$signature,
										'shop_id' => 		$merchant_id
										);
  
  
    			if( $curl = curl_init() ) 
				{
					curl_setopt($curl, CURLOPT_URL, $url_insales);
					curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($curl, CURLOPT_POST, true);
				
					//$stroka_post_zapros = "paid=1&amount=$amount&key=$key_from_DB&transaction_id=$transaction_id_from_DB&signature=$signature&shop_id=$merchant_id");

					curl_setopt($curl, CURLOPT_POSTFIELDS, $prepared_array );
					$out = curl_exec($curl);
					echo $out;
					curl_close($curl);
			  	}

			//========ОТПРАВЛЯЕМ POST-ЗАПРОС к INSALES========================================
	
	
	       	//---блок для логов----------------------------------
	
			//---блок для логов-----------------------------------
			
		}////=========если статус транзакции = SUCCESS========================================	
		}//=========если данные ЦЕЛОСТНЫЕ=====================================================
		
	}//===если ответ был от МандаринПей========================================================
		
}//=================================================================================================================================================================


		
else if (isset($_POST['shop_id']) )
{//==ПЕРВАЯ ПЛАТЕЖНАЯ ФОРМА ОТ МАГАЗИНА =============================================================================================================================

	//===получаем массив данных от InSales, создаем ассоциативный массив======
	$field = array ( 'shop_id'          => $_POST['shop_id'],
					 'amount'           => $_POST['amount'],
					 'transaction_id' 	=> $_POST['transaction_id'],
					 'key'				=> $_POST['key'],
					 'description'		=> $_POST['description'],
					 'order_id'			=> $_POST['order_id'],
					 'phone'			=> $_POST['phone'],
					 'email'			=> $_POST['email']   );
						  
	//===отдельно читаем значение sign - хэша от платежной системы============
	$sent_signature   =  $_POST['signature'];
	

	//===Проверяем целостность данных от InSales
	$secret = 'super';
	$right_signature = getSimpleHash ($secret, $field);
	
if ( $sent_signature == $right_signature)
{//===ЕСЛИ ПОДПИСЬ ДАННЫХ ПРАВИЛЬНАЯ - ОБРАБАТЫВАЕМ ПЕРЕСЫЛКУ на ПЛАТЕЖНЫЙ ПОРТАЛ====================

     //===записываем в базу данных значения key и transaction_id - это все внутренние
	 //   данные от InSales - и они не пересылаются MandarinPay                ======
			$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
			$mysqli->set_charset("utf8");

			//проверка на ошибку
			if ($mysqli->connect_error) {
				die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
			}

			//готовим переменные для записи
			$order_id = $field['order_id'];
			$key = $field['key'];
			$transaction = $field['transaction_id'];
						
			//проверяем, нет ли уже записи с ключом PRIMARY = $order_id
			$results = $mysqli->query("SELECT * FROM transactions WHERE order_id = $order_id");
		
			//если данной записи за таким ключом нет, то вносим
			if( !($results->num_rows) )
			{//===
				$insert_row = $mysqli->query("INSERT INTO transactions (`order_id`, `key`, `transaction`) 
											VALUES($order_id, '$key', $transaction)");
				
				if($insert_row)
				{
					//print 'Success! ID of last inserted record is : ' .$mysqli->insert_id .'<br />';
				}else
				{
					die('----Error : ('. $mysqli->errno .') '. $mysqli->error);
				}		
			}//====
			else
			{//===
				//while( $row = $results->fetch_assoc() )
				//{
				//	echo $row['order_id']."<br>\n";
				//	echo $row['key']."<br>\n";
				//	echo $row['transaction']."<br>\n";				
				//}
			}//===
			
			$mysqli->close();
			//-----------------------------------------------------------------------------------
			
			
			
	//-----------------------------------------------------------------------------------


	
	
	//===теперь надо взять из массива $field 4 параметра, что нужны для отправки на портал MandarinPay
	//===это:  merchantId  + orderId + price + email
	
		$field_for_mandarinpay = array( "email" 		=> 	$field['email'],
										"merchantId" 	=> 	$field['shop_id'],
										"orderId" 		=> 	$field['order_id'],
										"price" 		=>	$field['amount'] );
																  
   	//===расчитываем хеш для отправки на MandarinPay

	
	 //===== читаем SharedSec из базы данных, по известному merchantId===========================
			$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE);
			$mysqli->set_charset("utf8");

			if ($mysqli->connect_error) {
				die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
			}

			$merchant_id = $field_for_mandarinpay['merchantId'];
			$results = $mysqli->query("SELECT * FROM merchants WHERE merchant_id = $merchant_id");
			
			if( $row = $results->fetch_assoc() )
			{
				$mandarinpay_secret = 				$row['passw2'];
			}
			$results->free();
			$mysqli->close();
	//===== читаем SharedSec из базы данных, по известному merchantId===========================
	
	
	
		$hash_for_mandarinpay = getHash ($mandarinpay_secret, $field_for_mandarinpay);
						 
	
	//-------------для целей отладки записываем в файл данные, пришедшие из InSales---------
	
		$mytext = "Приняты данные по POST-запросу от магазина InSales"."\n";
		$i = 1;
	
		//-----------блок для логов---------------------------------------------------------
		$mytext = "Приняты данные по POST-запросу от магазина InSales"."\n";
		$i = 1;
	
		//перебираем все значения нашего массива field и пишем в строку для записи в файл

		//-----------блок для логов---------------------------------------------------------
	
	
	
	
	
	//------ДАЛЕЕ ПОСРЕДСТВОМ ФОРМЫ и костылей JS отсылаем POST форму на портал MadarinPay----
		//=========функция отправки первой платежной модули================================
		echo '<form action="https://secure.mandarinpay.com/Pay/" name="myform" method="POST">';
		foreach ($field_for_mandarinpay as $key => $val) 
		{ 
			echo '<input name="'.$key.'" value="'.$val.'" type="hidden" />';
		} 
		echo '<input name="sign" type="hidden" value="'. $hash_for_mandarinpay . '">'; 
		echo '</form>';
		
		echo '<script> document.forms["myform"].submit(); </script>';
		//=================================================================================
	//---------------------------------------------------------------------------------------

}//=======ЕСЛИ ПОДПИСЬ ДАННЫХ ПРАВИЛЬНАЯ=====================================================

}//====ОКОНЧАНИЕ БЛОКА - ОБРАБОТКА ПЕРВОЙ ПЛАТЕЖНОЙ ФОРМЫ=====================================================================================================
else{ echo "Перейдите на страницу магазина InSales";} //если ничего выбрано - ошибка 




	//====функция расчета хэша по алгоритму sha256================================
	function getSimpleHash ($secret, $fields )
	{
		//ksort($fields); //ничего не сортируем, у нас типа все и так зафиксировано
        $secret_t = ''; 
        foreach($fields as $key => $val)
        {                  
            $secret_t = $secret_t . ';' . $val;
		}
           //убираем первый символ «;»
            $secret_t = substr($secret_t, 1) . ';' . $secret;

		//считаем хэш по алгоритму sha256 и возвращаем его
		return md5($secret_t);
	}//===============================================================================
	
	//====функция расчета хэша по алгоритму sha256================================
	function getHash ($secret, $fields )
	{
		ksort($fields); 
        $secret_t = ''; 
        foreach($fields as $key => $val)
        {                  
            $secret_t = $secret_t . '-' . $val;
		}
           //убираем первый символ «-»
            $secret_t = substr($secret_t, 1) . '-' . $secret;

		//считаем хэш по алгоритму sha256 и возвращаем его
		return hash('sha256', $secret_t);
	}//===============================================================================

?>