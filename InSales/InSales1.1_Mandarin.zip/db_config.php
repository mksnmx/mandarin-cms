<?php
    //база данных, которую мы вынуждены завести так как вводится
    //срипт-прокси, скрипт-посредник	
    define('DB_USER', "p342630_insales"); //логин админа БД
    define('DB_PASSWORD', "Pkp2sG5P35"); // пароль админа БД
    define('DB_DATABASE', "p342630_insales"); // база данных
    define('DB_SERVER', "p342630.mysql.ihc.ru"); // сервер
?>