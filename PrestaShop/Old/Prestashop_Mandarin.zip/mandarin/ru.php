<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_8d5d3d3d5f1803ebcb46fa11d4dcc4c8'] = 'Принимать платежи по банковским картам онлайн';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Вы уверены, что хотите удалить эти пункты?';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Подтверждение';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Настройки обновлены';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_6a26f548831e6a8c26bfbbd9f6ec61e0'] = 'Помощь';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_02011e44e37fcbd94d398cc4cefdd4cb'] = 'Введите данные данные в вашем личном кабинете';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_36f84bf8b31273d444db589182b927b6'] = 'Связаться с нами';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_b04f2c8a90cfc485fc990dc8dc4ba293'] = 'Настройки платежного модуля';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_c45ae2ec9c671dbb62a9a61bc885075a'] = 'Адрес платежного шлюза';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_490c267973e3a6bc12ae1ba39ce26f7c'] = 'Параметр MerchantId Вы получаете в системе MandarinPay';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_952bf87c967660b7bbd4e1eb08cefc92'] = 'Secret';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_44251a575c40f7080f34a8c6507f80bf'] = 'Параметр Secret Вы получаете в системе MandarinPay.';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_86f1814f4d029525616b291520a42ebf'] = 'Статус заказа \"ОПЛАЧЕНО\"';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_6309e197fe1fed67fc52e5ab74ef2d56'] = 'Если не уверены в этом параметре, оставьте значение по умолчанию';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_ab9c43b7555c215f101e702ad0786d47'] = 'Вы можете использовать свой кастомный статус заказа \"ОПЛАЧЕНО\"';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_a4d3b161ce1309df1c4e25df28694b7b'] = 'Подтвердить изменения';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_75d70ce342c3724ffdaaa4c3653939d9'] = 'Оплатить банковской картой онлайн';
$_MODULE['<{mandarinpay}default-bootstrap>mandarinpay_0abb604f6c818ac165abc2c87dbd8f94'] = 'Оплатить банковской картой онлайн';
