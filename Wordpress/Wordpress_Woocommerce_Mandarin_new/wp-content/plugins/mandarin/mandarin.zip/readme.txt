=== Mandarin-Payment-integration ===
Contributors: mandarinltd
Tested up to: 5.9
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Mandarin Payment integration for WordPress (WooCommerce)

Позволяет принимать оплату корзины через платежный шлюз Mandarin.

  1.  Распакуйте архив Wordpress_Woocommerce_Mandarin_new.zip в корень сайта
  2.  Панель администратора -> Плагины -> MandarinPay -> Activate
  3.  Панель администратора -> Плагины -> MandarinPay -> Настроить
  4.  Укажите Merchant Id и Merchant Secret
